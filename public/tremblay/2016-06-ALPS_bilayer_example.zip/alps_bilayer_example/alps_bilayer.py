# run with
#   $ alpspython alps_bilayer.py
#
# Quasi-2D antiferromegnetic Heisenberg square lattice with bilayer coupling:
# Simulate magnetic field scan with SSE

import numpy as np
import matplotlib.pyplot as plt
from copy import deepcopy
import pyalps, pyalps.plot  # ALPS python tools


# prepare the input parameters
mub = .6717
gfactor = 2.22
parms = []
for h in np.concatenate([np.linspace(0, 5, 7), np.linspace(6, 23, 6), np.linspace(24, 30, 5)]):
    parms.append({ 
          'LATTICE_LIBRARY' : 'bilayer_lattices.xml',  # use our custom lattice library
          'LATTICE'        : "bilayer",     # the lattice we defined
          'MODEL'          : "spin",
          'local_S'        : 0.5,       # simulate a spin-1/2 model
          'T'              : 0.5,       # temperature
          'J0'             : 10.2 ,     # antiferromagnetic in-plane coupling
          'J1'             : 0.5,       # antiferromagnetic inter-layer coupling between bilayers
          'J2'             : -0.5,      # ferromagnetic inter-layer coupling within bilayer
          'THERMALIZATION' : 5000,      # equilibration time
          'SWEEPS'         : 50000,     # Monte Carlo sweeps with measurements
          'L'              : 4,         # system extent along layers
          'H'              : 2,         # system extent in stacking direction
          'h'              : mub*gfactor*h  # magnetic field
        })

# write the input files and run the simulation
prefix = 'bilayer'
input_files = pyalps.writeInputFiles(prefix, parms)
res = pyalps.runApplication('dirloop_sse', input_files, writexml=True, Tmin=5, MPI=4)

# load result data
data = pyalps.loadMeasurements(pyalps.getResultFiles(prefix=prefix))

# collect named observables as functions of field B
for d in pyalps.flatten(data):
    d.props['B'] = d.props['h'] / (mub*gfactor)
magnetization    = pyalps.collectXY(data,'B','Magnetization')[0]
absmagnetization = pyalps.collectXY(data,'B','|Magnetization|')[0]
m2               = pyalps.collectXY(data,'B','Magnetization^2')[0]
for d in (magnetization, absmagnetization, m2):
    d.props['xlabel'] = 'field $B$ [$T$]'

# normalize
nsites = magnetization.props['L']**2 * magnetization.props['H']
for d in (magnetization, absmagnetization):
    d.y /= nsites
m2.y /= nsites**2

# calculate susceptibility \chi_c = N \beta (<m^2> - <|m|>^2)
# Algebraic operations automatically calculate errors via jackknife analysis
susceptibility = deepcopy(m2)
susceptibility.y -= absmagnetization.y**2
susceptibility.y *= nsites / susceptibility.props['T']
susceptibility.props['ylabel'] = susceptibility.props['observable'] = 'Susceptibility $\\chi_c$'

# plot magnetization and susceptibility
plt.figure()
pyalps.plot.plot(magnetization)
plt.figure()
pyalps.plot.plot(susceptibility)

# show the plots
plt.show()
